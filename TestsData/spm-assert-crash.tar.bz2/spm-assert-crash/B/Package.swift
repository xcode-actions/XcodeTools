// swift-tools-version:5.5
import PackageDescription

import Foundation


let package = Package(
	name: "B",
	products: [
		.library(name: "B", targets: ["B"])
	],
	dependencies: [
		.package(
			url: URL(fileURLWithPath: #filePath).deletingLastPathComponent().deletingLastPathComponent().appendingPathComponent("A").absoluteString,
			from: "0.2.0-beta.1"
		)
	],
	targets: [
		.target(name: "B", dependencies: [.product(name: "A", package: "A")], path: "Sources")
	]
)
