public struct B {
	public init() {}
}
