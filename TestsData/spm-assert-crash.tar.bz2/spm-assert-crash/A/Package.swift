// swift-tools-version:5.5
import PackageDescription


let package = Package(
	name: "A",
	products: [
		.library(name: "A", targets: ["A"])
	],
	targets: [
		.target(name: "A", path: "Sources")
	]
)
