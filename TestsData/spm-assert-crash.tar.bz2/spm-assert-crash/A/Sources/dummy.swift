public struct A {
	public init() {}
}
