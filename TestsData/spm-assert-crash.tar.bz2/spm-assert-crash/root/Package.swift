// swift-tools-version:5.5
import PackageDescription

import Foundation


let parentFolder = URL(fileURLWithPath: #filePath).deletingLastPathComponent().deletingLastPathComponent()
let package = Package(
	name: "root",
	dependencies: [
		.package(url: parentFolder.appendingPathComponent("A").absoluteString, from: "0.1.0"),
		.package(url: parentFolder.appendingPathComponent("B").absoluteString, from: "0.1.0"),
	],
	targets: [
		.target(name: "root", dependencies: [
			.product(name: "A", package: "A"),
			.product(name: "B", package: "B"),
		], path: "Sources")
	]
)
